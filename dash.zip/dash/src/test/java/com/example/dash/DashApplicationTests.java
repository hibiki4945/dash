package com.example.dash;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DashApplicationTests {

	@Test
	void contextLoads() {
	}

}
